Ebinisa Olorunninwo - Cloud DevOps Engr Nanodegree

Project 1: Deploy Static Website on AWS

URLs:

https://d255tqhrx4guvw.cloudfront.net/

http://my-357832444257-bucket.s3-website-us-east-1.amazonaws.com/

https://my-357832444257-bucket.s3.amazonaws.com/index.html

